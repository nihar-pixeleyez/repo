<script setup>
// import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <router-view></router-view>
</template>
