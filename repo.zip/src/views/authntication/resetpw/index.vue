<script setup>
import { ref } from 'vue';
import rtlLtr from "@/components/rtlLtr.vue";
const currentYear = ref(new Date().getFullYear());
</script>
<template>
    <!-- Start Layout -->
    <div class="bg-[#f9fbfd] dark:bg-dark text-black min-h-screen relative z-10">

        <!-- Start Background Images -->
        <div class="bg-[url('../images/bg-main.png')] bg-black dark:bg-purple min-h-[220px] sm:min-h-[50vh] bg-bottom w-full -z-10 absolute"></div>
        <!-- End Background Images -->

        <!-- Start Header -->
        <header>
            <nav class="px-4 lg:px-7 py-4 max-w-[1440px] mx-auto">
                <div class="flex flex-wrap items-center justify-between">
                    <router-link to="/index" class="flex items-center">
                        <img src="@/assets/images/logo-light.svg" class="mx-auto dark-logo h-7 dark:hidden" alt="logo">
                        <img src="@/assets/images/light.svg" class="hidden mx-auto light-logo h-7 dark:block" alt="logo">
                    </router-link>
                    <div class="flex items-center lg:order-2">
                        <router-link to="/signup" class="btn bg-purple dark:border-white dark:bg-white dark:text-black dark:hover:bg-white/90 border border-purple rounded-md text-white transition-all duration-300 hover:bg-purple/[0.85] hover:border-purple/[0.85]">Buy Now</router-link>
                    </div>
                </div>
            </nav>
        </header>
        <!-- End Header -->

        <!-- Start Main Content -->
        <div class="min-h-[calc(100vh-134px)] py-4 px-4 sm:px-12 flex justify-center items-center max-w-[1440px] mx-auto">
            <div class="max-w-[550px] flex-none w-full bg-white border border-black/10 p-6 sm:p-10 lg:px-10 lg:py-14 rounded-2xl dark:bg-darklight dark:border-darkborder">
                <h1 class="mb-2 text-2xl font-semibold text-center dark:text-white">Forgot your password?</h1>
                <p class="text-center text-muted mb-7 dark:text-darkmuted">Enter your Email and instructions will be sent to you!</p>
                <form class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div class="sm:col-span-2">
                        <input type="text" value="" placeholder="Email" class="form-input" required>
                    </div>
                    <button type="submit" class="btn sm:col-span-2 w-full py-3.5 text-base bg-purple border border-purple rounded-md text-white transition-all duration-300 hover:bg-purple/[0.85] hover:border-purple/[0.85]">
                        Email password reset link
                    </button>
                </form>
                <p class="mt-5 text-center">
                    <router-link to="/index" class="flex items-center justify-center gap-1 leading-none text-black dark:text-white">
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="inline-block w-5 h-5">
                                <path fill="currentColor" d="M19 21.0001H5C4.44772 21.0001 4 20.5524 4 20.0001V11.0001L1 11.0001L11.3273 1.61162C11.7087 1.26488 12.2913 1.26488 12.6727 1.61162L23 11.0001L20 11.0001V20.0001C20 20.5524 19.5523 21.0001 19 21.0001ZM6 19.0001H18V9.15757L12 3.70302L6 9.15757V19.0001ZM8 15.0001H16V17.0001H8V15.0001Z"></path>
                            </svg>
                        </span>
                        Back to home
                    </router-link>
                </p>
            </div>
        </div>
        <!-- End Main Content -->

        <!-- Start Footer -->
        <footer class="py-5 text-center text-black dark:text-white/80 max-w-[1440px] mx-auto">
            <div>
                &copy;
                {{ currentYear }}
                Sliced.
                <span>Crafted with
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-4 h-4 inline-block relative -mt-[2px]">
                        <path d="M12.001 4.52853C14.35 2.42 17.98 2.49 20.2426 4.75736C22.5053 7.02472 22.583 10.637 20.4786 12.993L11.9999 21.485L3.52138 12.993C1.41705 10.637 1.49571 7.01901 3.75736 4.75736C6.02157 2.49315 9.64519 2.41687 12.001 4.52853Z" class="fill-purple"></path>
                    </svg>
                    by SRBThemes
                </span>
            </div>
        </footer>
    </div>
    <!-- End Layout -->

       <rtlLtr/>
</template>


