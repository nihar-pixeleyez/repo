    <template>
        <Layout>
            <headTitle title="Account Settings" items="Users" />

            <!-- Start All Card -->
            <div class="flex flex-col gap-4 min-h-[calc(100vh-212px)]">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                        <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Profile Details</h2>
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                            <div class="space-y-2">
                                <label>First Name</label>
                                <input type="text" class="form-input" placeholder="First Name" value="Stevens" required="">
                            </div>
                            <div class="space-y-2">
                                <label>Last Name</label>
                                <input type="text" class="form-input" placeholder="Last Name" value="Laurie" required="">
                            </div>
                            <div class="space-y-2 md:col-span-2">
                                <label>Username</label>
                                <input type="text" class="form-input" placeholder="username" value="Stevens_Laurie" required="">
                            </div>
                            <div class="space-y-2 md:col-span-2">
                                <label>Your email</label>
                                <input type="email" class="form-input" placeholder="Email" value="example@example.com" required="">
                            </div>
                            <div class="space-y-2 md:col-span-2">
                                <label>Profession</label>
                                <input type="text" class="form-input" placeholder="Profession" value="Ui/Ux Designer" required="">
                            </div>
                            <div class="space-y-2 md:col-span-2">
                                <label>Location</label>
                                <input type="text" class="form-input" placeholder="Location" value="Canada" required="">
                            </div>
                            <div class="space-y-2 md:col-span-2">
                                <label>Website</label>
                                <input type="text" class="form-input" placeholder="Website" value="websiteexample.com" required="">
                            </div>
                            <div class="space-y-2 md:col-span-2">
                                <label>Phone</label>
                                <input type="phone" class="form-input" placeholder="Phone" value=" +123 45678 789" required="">
                            </div>
                            <div class="flex flex-wrap gap-3">
                                <button type="button" class="btn bg-purple border border-purple rounded-md text-white transition-all duration-300 hover:bg-purple/[0.85] hover:border-purple/[0.85]">Save</button>
                                <button type="button" class="btn bg-light border border-light rounded-md text-black transition-all duration-300 hover:bg-light/[0.85] hover:border-light/[0.85]">Discard</button>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                        <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Your Photo</h2>
                        <div class="grid grid-cols-1 gap-4">
                            <div class="flex items-center gap-4">
                                <img src="@/assets/images/user.png" class="w-16 h-16 rounded-full" alt="">
                                <div>
                                    <h5 class="text-lg font-bold dark:text-white">Stevens Laurie</h5>
                                    <p class="text-muted mt-0.5 dark:text-darkmuted">Ui/Ux Designer</p>
                                </div>
                            </div>
                            <div id="FileUpload" class="relative block w-full p-4 border-2 border-dashed rounded appearance-none cursor-pointer border-primary bg-light/20 dark:bg-white/5 dark:border-darkborder">
                                <input type="file" accept="images/*" class="absolute inset-0 z-50 w-full h-full p-0 m-0 outline-none opacity-0 cursor-pointer">
                                <div class="flex flex-col items-center justify-center space-y-3 dark:text-darkmuted">
                                    <span class="flex items-center justify-center rounded-full h-14 w-14 bg-light/50 dark:bg-white/10 dark:text-white">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="inline-block w-5 h-5">
                                            <path fill="currentColor" d="M4 19H20V12H22V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20V12H4V19ZM13 9V16H11V9H6L12 3L18 9H13Z"></path>
                                        </svg>
                                    </span>
                                    <p><span class="text-purple">Click to upload</span> or drag and drop</p>
                                    <p>SVG, PNG, JPG or GIF</p>
                                    <p>(max, 100 X 100px)</p>
                                </div>
                            </div>
                            <div class="flex flex-wrap gap-3">
                                <button type="button" class="btn bg-purple border border-purple rounded-md text-white transition-all duration-300 hover:bg-purple/[0.85] hover:border-purple/[0.85]">Save</button>
                                <button type="button" class="btn bg-light border border-light rounded-md text-black transition-all duration-300 hover:bg-light/[0.85] hover:border-light/[0.85]">Discard</button>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                        <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Change Password</h2>
                        <div class="space-y-4">
                            <div class="space-y-2">
                                <label>Current Password</label>
                                <input type="password" class="form-input" placeholder="Current Password" required="">
                            </div>
                            <div class="space-y-2">
                                <label>New Password</label>
                                <input type="password" class="form-input" placeholder="New Password" required="">
                            </div>
                            <div class="space-y-2">
                                <label>Confirm Password</label>
                                <input type="password" class="form-input" placeholder="Confirm Password" required="">
                            </div>
                            <div class="flex flex-wrap gap-3">
                                <button type="button" class="btn bg-purple border border-purple rounded-md text-white transition-all duration-300 hover:bg-purple/[0.85] hover:border-purple/[0.85]">Save</button>
                                <button type="button" class="btn bg-light border border-light rounded-md text-black transition-all duration-300 hover:bg-light/[0.85] hover:border-light/[0.85]">Discard</button>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                        <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Notifications</h2>
                        <div class="space-y-4">
                            <div class="flex items-center justify-between gap-4">
                                Email Notifications
                                <div class="inline-block togglebutton">
                                    <label for="toggleD2" class="flex items-center cursor-pointer">
                                        <div class="relative">
                                            <input type="checkbox" id="toggleD2" class="sr-only">
                                            <div class="block band bg-black/10 w-[54px] h-[29px] rounded-full dark:bg-dark"></div>
                                            <div class="dot absolute left-[3px] top-[2px] bg-white w-6 h-6 rounded-full transition"></div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                            <div class="flex items-center justify-between gap-4">
                                Billing Updates
                                <div class="inline-block togglebutton">
                                    <label for="toggleD3" class="flex items-center cursor-pointer">
                                        <div class="relative">
                                            <input type="checkbox" id="toggleD3" class="sr-only" checked>
                                            <div class="block band bg-black/10 w-[54px] h-[29px] rounded-full dark:bg-dark"></div>
                                            <div class="dot absolute left-[3px] top-[2px] bg-white w-6 h-6 rounded-full transition"></div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                            <div class="flex items-center justify-between gap-4">
                                API Access
                                <div class="inline-block togglebutton">
                                    <label for="toggleD4" class="flex items-center cursor-pointer">
                                        <div class="relative">
                                            <input type="checkbox" id="toggleD4" class="sr-only">
                                            <div class="block band bg-black/10 w-[54px] h-[29px] rounded-full dark:bg-dark"></div>
                                            <div class="dot absolute left-[3px] top-[2px] bg-white w-6 h-6 rounded-full transition"></div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                            <div class="flex items-center justify-between gap-4">
                                Newsletters
                                <div class="inline-block togglebutton">
                                    <label for="toggleD5" class="flex items-center cursor-pointer">
                                        <div class="relative">
                                            <input type="checkbox" id="toggleD5" class="sr-only" checked>
                                            <div class="block band bg-black/10 w-[54px] h-[29px] rounded-full dark:bg-dark"></div>
                                            <div class="dot absolute left-[3px] top-[2px] bg-white w-6 h-6 rounded-full transition"></div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </Layout>
    </template>

<script setup>
import Layout from '@/layouts/vertical.vue'; // Adjust the path as per your project structure
import headTitle from '@/components/head-title.vue'; // Adjust the path as per your project structure
const title = 'Settings';
</script>