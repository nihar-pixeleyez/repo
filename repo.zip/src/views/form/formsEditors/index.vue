<script setup>
import { ref, onMounted } from "vue";
import Layout from '@/layouts/vertical.vue';
import headTitle from '@/components/head-title.vue';

</script>
<template>
    <Layout>
        <headTitle title="Editors" items="Forms" />

        <div class="flex flex-col gap-4 min-h-[calc(100vh-212px)]">
            <div class="grid grid-cols-1 gap-4">
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Editor</h2>
                    <div class="relative">
                        <div class="text-black" x-data="app()" x-init="init($refs.sliced)">
                            <div class="overflow-hidden bg-white border rounded-md border-black/10 dark:bg-darklight dark:border-darkborder">
                                <div class="flex flex-wrap w-full border-b border-black/10 dark:border-darkborder">
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('bold')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M8 11H12.5C13.8807 11 15 9.88071 15 8.5C15 7.11929 13.8807 6 12.5 6H8V11ZM18 15.5C18 17.9853 15.9853 20 13.5 20H6V4H12.5C14.9853 4 17 6.01472 17 8.5C17 9.70431 16.5269 10.7981 15.7564 11.6058C17.0979 12.3847 18 13.837 18 15.5ZM8 13V18H13.5C14.8807 18 16 16.8807 16 15.5C16 14.1193 14.8807 13 13.5 13H8Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('italic')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M15 20H7V18H9.92661L12.0425 6H9V4H17V6H14.0734L11.9575 18H15V20Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 mr-1 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('underline')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M8 3V12C8 14.2091 9.79086 16 12 16C14.2091 16 16 14.2091 16 12V3H18V12C18 15.3137 15.3137 18 12 18C8.68629 18 6 15.3137 6 12V3H8ZM4 20H20V22H4V20Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('formatBlock', 'P')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M12 6V21H10V16C6.68629 16 4 13.3137 4 10C4 6.68629 6.68629 4 10 4H20V6H17V21H15V6H12ZM10 6C7.79086 6 6 7.79086 6 10C6 12.2091 7.79086 14 10 14V6Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('formatBlock', 'H1')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M13 20H11V13H4V20H2V4H4V11H11V4H13V20ZM21.0005 8V20H19.0005L19 10.204L17 10.74V8.67L19.5005 8H21.0005Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('formatBlock', 'H2')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M4 4V11H11V4H13V20H11V13H4V20H2V4H4ZM18.5 8C20.5711 8 22.25 9.67893 22.25 11.75C22.25 12.6074 21.9623 13.3976 21.4781 14.0292L21.3302 14.2102L18.0343 18H22V20H15L14.9993 18.444L19.8207 12.8981C20.0881 12.5908 20.25 12.1893 20.25 11.75C20.25 10.7835 19.4665 10 18.5 10C17.5818 10 16.8288 10.7071 16.7558 11.6065L16.75 11.75H14.75C14.75 9.67893 16.4289 8 18.5 8Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 mr-1 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('formatBlock', 'H3')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M22 8L21.9984 10L19.4934 12.883C21.0823 13.3184 22.25 14.7728 22.25 16.5C22.25 18.5711 20.5711 20.25 18.5 20.25C16.674 20.25 15.1528 18.9449 14.8184 17.2166L16.7821 16.8352C16.9384 17.6413 17.6481 18.25 18.5 18.25C19.4665 18.25 20.25 17.4665 20.25 16.5C20.25 15.5335 19.4665 14.75 18.5 14.75C18.214 14.75 17.944 14.8186 17.7056 14.9403L16.3992 13.3932L19.3484 10H15V8H22ZM4 4V11H11V4H13V20H11V13H4V20H2V4H4Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('insertUnorderedList')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M11 4H21V6H11V4ZM11 8H17V10H11V8ZM11 14H21V16H11V14ZM11 18H17V20H11V18ZM3 4H9V10H3V4ZM5 6V8H7V6H5ZM3 14H9V20H3V14ZM5 16V18H7V16H5Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 mr-1 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('insertOrderedList')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M5.75024 3.5H4.71733L3.25 3.89317V5.44582L4.25002 5.17782L4.25018 8.5H3V10H7V8.5H5.75024V3.5ZM10 4H21V6H10V4ZM10 11H21V13H10V11ZM10 18H21V20H10V18ZM2.875 15.625C2.875 14.4514 3.82639 13.5 5 13.5C6.17361 13.5 7.125 14.4514 7.125 15.625C7.125 16.1106 6.96183 16.5587 6.68747 16.9167L6.68271 16.9229L5.31587 18.5H7V20H3.00012L2.99959 18.8786L5.4717 16.035C5.5673 15.9252 5.625 15.7821 5.625 15.625C5.625 15.2798 5.34518 15 5 15C4.67378 15 4.40573 15.2501 4.37747 15.5688L4.3651 15.875H2.875V15.625Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('justifyLeft')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M3 4H21V6H3V4ZM3 19H17V21H3V19ZM3 14H21V16H3V14ZM3 9H17V11H3V9Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('justifyCenter')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M3 4H21V6H3V4ZM3 19H21V21H3V19ZM3 14H21V16H3V14ZM3 9H21V11H3V9Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                    <button class="w-10 h-10 text-black outline-none focus:outline-none dark:text-white dark:hover:text-purple hover:text-purple active:bg-light/50" @click="format('justifyRight')">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 mx-auto">
                                            <path d="M3 4H21V6H3V4ZM7 19H21V21H7V19ZM3 14H21V16H3V14ZM7 9H21V11H7V9Z" fill="currentColor"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="w-full">
                                    <iframe ref="sliced" class="w-full min-h-[calc(100vh-542px)] md:min-h-[calc(100vh-452px)] overflow-y-auto text-editor"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </Layout>
</template>