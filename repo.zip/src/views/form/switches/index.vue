<script setup>
import { ref } from "vue";
import Layout from '@/layouts/vertical.vue';
import headTitle from '@/components/head-title.vue';
</script>
<template>
    <Layout>
        <headTitle title="Switches" items="Forms" />

        <div class="flex flex-col gap-4 min-h-[calc(100vh-212px)]">
            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Switches Solid</h2>
                    <div class="inline-block togglebutton">
                        <label for="toggleD1" class="flex items-center cursor-pointer">
                            <div class="relative">
                                <input type="checkbox" id="toggleD1" class="sr-only">
                                <div class="block band bg-black/10 w-[54px] h-[29px] dark:bg-darkmuted/50"></div>
                                <div class="dot absolute left-[3px] top-[2px] bg-white w-6 h-6 transition dark:bg-dark"></div>
                            </div>
                        </label>
                    </div>
                </div>
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Switches Solid Rounded</h2>
                    <div class="inline-block togglebutton">
                        <label for="toggleD2" class="flex items-center cursor-pointer">
                            <div class="relative">
                                <input type="checkbox" id="toggleD2" class="sr-only">
                                <div class="block band bg-black/10 w-[54px] h-[29px] rounded-full dark:bg-darkmuted/50"></div>
                                <div class="dot absolute left-[3px] top-[2px] bg-white w-6 h-6 rounded-full transition dark:bg-dark"></div>
                            </div>
                        </label>
                    </div>
                </div>
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Switches Outline</h2>
                    <div class="inline-block togglebutton out-line">
                        <label for="toggleD3" class="flex items-center cursor-pointer">
                            <div class="relative">
                                <input type="checkbox" id="toggleD3" class="sr-only">
                                <div class="block band border border-black/10 w-[52px] h-[29px] dark:bg-darkmuted/50"></div>
                                <div class="dot absolute left-1 top-[3.5px] bg-black/50 w-[22PX] h-[22PX] transition dark:bg-dark"></div>
                            </div>
                        </label>
                    </div>
                </div>
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Switches Outline Rounded</h2>
                    <div class="inline-block togglebutton out-line">
                        <label for="toggleD4" class="flex items-center cursor-pointer">
                            <div class="relative">
                                <input type="checkbox" id="toggleD4" class="sr-only">
                                <div class="block band border border-black/10 w-[54px] h-[29px] rounded-full dark:bg-darkmuted/50"></div>
                                <div class="dot absolute left-[5px] top-[3.5px] bg-black/50 w-[22PX] h-[22PX] rounded-full transition dark:bg-dark"></div>
                            </div>
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </Layout>
</template>