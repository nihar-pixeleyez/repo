<script setup>
import { ref } from 'vue';
import Layout from '@/layouts/vertical.vue';
import headTitle from '@/components/head-title.vue';

const tabs1 = ref([
    { id: 'profile1', label: 'Profile', content: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                                                of type and scrambled it to make a type specimen book.` },
    { id: 'dashboard1', label: 'Dashboard', content: `It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal
                                                distribution of letters, as opposed to using 'Content here,` },
    { id: 'settings1', label: 'Settings', content: `Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin
                                                professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur,` },
    { id: 'contacts1', label: 'Contacts', content: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly
                                                believable.` },
]);
const activeTab1 = ref('profile1');

const handleTabClick1 = (tabId) => {
    activeTab1.value = tabId;
};

const tabs2 = ref([
    { id: 'profile2', label: 'Profile', content: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                                                of type and scrambled it to make a type specimen book.` },
    { id: 'dashboard2', label: 'Dashboard', content: `It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal
                                                distribution of letters, as opposed to using 'Content here,` },
    { id: 'settings2', label: 'Settings', content: `Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin
                                                professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur,` },
    { id: 'contacts2', label: 'Contacts', content: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly
                                                believable.` },
]);
const activeTab2 = ref('profile2');

const handleTabClick2 = (tabId) => {
    activeTab2.value = tabId;
};

const tabsWithIcons = ref([
    { id: 'profile', label: 'Profile', icon: 'M20 22H18V20C18 18.3431 16.6569 17 15 17H9C7.34315 17 6 18.3431 6 20V22H4V20C4 17.2386 6.23858 15 9 15H15C17.7614 15 20 17.2386 20 20V22ZM12 13C8.68629 13 6 10.3137 6 7C6 3.68629 8.68629 1 12 1C15.3137 1 18 3.68629 18 7C18 10.3137 15.3137 13 12 13ZM12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z', content: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                                                of type and scrambled it to make a type specimen book.` },
    { id: 'dashboard', label: 'Dashboard', icon: `M13 21V11H21V21H13ZM3 13V3H11V13H3ZM9 11V5H5V11H9ZM3 21V15H11V21H3ZM5 19H9V17H5V19ZM15 19H19V13H15V19ZM13 3H21V9H13V3ZM15 5V7H19V5H15Z`, content: `It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal
                                                distribution of letters, as opposed to using 'Content here,` },
    { id: 'settings', label: 'Settings', icon: 'M2 11.9998C2 11.1353 2.1097 10.2964 2.31595 9.49631C3.40622 9.55283 4.48848 9.01015 5.0718 7.99982C5.65467 6.99025 5.58406 5.78271 4.99121 4.86701C6.18354 3.69529 7.66832 2.82022 9.32603 2.36133C9.8222 3.33385 10.8333 3.99982 12 3.99982C13.1667 3.99982 14.1778 3.33385 14.674 2.36133C16.3317 2.82022 17.8165 3.69529 19.0088 4.86701C18.4159 5.78271 18.3453 6.99025 18.9282 7.99982C19.5115 9.01015 20.5938 9.55283 21.6841 9.49631C21.8903 10.2964 22 11.1353 22 11.9998C22 12.8643 21.8903 13.7032 21.6841 14.5033C20.5938 14.4468 19.5115 14.9895 18.9282 15.9998C18.3453 17.0094 18.4159 18.2169 19.0088 19.1326C17.8165 20.3043 16.3317 21.1794 14.674 21.6383C14.1778 20.6658 13.1667 19.9998 12 19.9998C10.8333 19.9998 9.8222 20.6658 9.32603 21.6383C7.66832 21.1794 6.18354 20.3043 4.99121 19.1326C5.58406 18.2169 5.65467 17.0094 5.0718 15.9998C4.48848 14.9895 3.40622 14.4468 2.31595 14.5033C2.1097 13.7032 2 12.8643 2 11.9998ZM6.80385 14.9998C7.43395 16.0912 7.61458 17.3459 7.36818 18.5236C7.77597 18.8138 8.21005 19.0652 8.66489 19.2741C9.56176 18.4712 10.7392 17.9998 12 17.9998C13.2608 17.9998 14.4382 18.4712 15.3351 19.2741C15.7899 19.0652 16.224 18.8138 16.6318 18.5236C16.3854 17.3459 16.566 16.0912 17.1962 14.9998C17.8262 13.9085 18.8225 13.1248 19.9655 12.7493C19.9884 12.5015 20 12.2516 20 11.9998C20 11.7481 19.9884 11.4981 19.9655 11.2504C18.8225 10.8749 17.8262 10.0912 17.1962 8.99982C16.566 7.90845 16.3854 6.65378 16.6318 5.47605C16.224 5.18588 15.7899 4.93447 15.3351 4.72552C14.4382 5.52844 13.2608 5.99982 12 5.99982C10.7392 5.99982 9.56176 5.52844 8.66489 4.72552C8.21005 4.93447 7.77597 5.18588 7.36818 5.47605C7.61458 6.65378 7.43395 7.90845 6.80385 8.99982C6.17376 10.0912 5.17754 10.8749 4.03451 11.2504C4.01157 11.4981 4 11.7481 4 11.9998C4 12.2516 4.01157 12.5015 4.03451 12.7493C5.17754 13.1248 6.17376 13.9085 6.80385 14.9998ZM12 14.9998C10.3431 14.9998 9 13.6567 9 11.9998C9 10.343 10.3431 8.99982 12 8.99982C13.6569 8.99982 15 10.343 15 11.9998C15 13.6567 13.6569 14.9998 12 14.9998ZM12 12.9998C12.5523 12.9998 13 12.5521 13 11.9998C13 11.4475 12.5523 10.9998 12 10.9998C11.4477 10.9998 11 11.4475 11 11.9998C11 12.5521 11.4477 12.9998 12 12.9998Z', content: `Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin
                                                professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur,` },
    { id: 'contacts', label: 'Contacts', icon: 'M22 17.0022C21.999 19.8731 19.9816 22.2726 17.2872 22.8616L16.6492 20.9476C17.8532 20.7511 18.8765 20.0171 19.4649 19H17C15.8954 19 15 18.1046 15 17V13C15 11.8954 15.8954 11 17 11H19.9381C19.446 7.05369 16.0796 4 12 4C7.92038 4 4.55399 7.05369 4.06189 11H7C8.10457 11 9 11.8954 9 13V17C9 18.1046 8.10457 19 7 19H4C2.89543 19 2 18.1046 2 17V12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12V12.9987V13V17V17.0013V17.0022ZM20 17V13H17V17H20ZM4 13V17H7V13H4Z', content: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly
                                                believable.` },
]);
const activeTabWithIcon = ref('profile');

const handleIconTabClick = (tabId) => {
    activeTabWithIcon.value = tabId;
};

const activePillsTabs = ref('profile');
const handlePillsTabClick = (tabId) => {
    activePillsTabs.value = tabId;
};


const activeBarTabs = ref('profile');

const handleBarWithTabClick = (tab) => {
    activeBarTabs.value = tab;
};

const activeBarsTabs = ref('profile3');

const tabsWithoutIcons = [
    { id: 'profile3', label: 'Profile', content: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                                                of type and scrambled it to make a type specimen book.` },
    { id: 'dashboard3', label: 'Dashboard', content: `It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal
                                                distribution of letters, as opposed to using 'Content here,` },
    { id: 'settings3', label: 'Settings', content: 'Contrary to popular belief...' },
    { id: 'contacts3', label: 'Contacts', content: 'There are many variations of passages...' },
];

const handleBarTabClickd = (tab) => {
    activeBarsTabs.value = tab;
};
</script>

<template>
    <Layout>
        <headTitle title="Tabs" items="Components" />

        <div class="flex flex-col gap-4 min-h-[calc(100vh-212px)]">
            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                <!-- Default -->
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Default Tabs</h2>
                    <ul class="flex flex-wrap text-sm text-center border-b border-black/10 dark:border-darkborder">
                        <li v-for="tab in tabs1" :key="tab.id" class="ltr:mr-2 rtl:ml-2">
                            <button @click="handleTabClick1(tab.id)" class="inline-block p-4 rounded-t-lg" :class="{
                                'bg-purple/10 text-purple': activeTab1 === tab.id,
                                'bg-transparent font-normal text-muted dark:text-darkmuted dark:hover:text-purple hover:bg-purple/10 hover:text-purple': activeTab1 !== tab.id
                            }">
                                {{ tab.label }}
                            </button>
                        </li>
                        <li>
                            <button class="inline-block p-4 rounded-t-lg cursor-not-allowed text-muted/50" disabled>Disabled</button>
                        </li>
                    </ul>
                    <div class="tab-content mt-3 text-[13px]">
                        <div v-for="tab in tabs1" :key="tab.id" v-show="activeTab1 === tab.id">
                            <p>{{ tab.content }}</p>
                        </div>
                    </div>
                </div>
                <!-- Tabs with underline -->
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">Tabs with underline</h2>
                    <ul class="flex flex-wrap -mb-px text-sm text-center border-b border-black/10 dark:border-darkborder">
                        <li v-for="tab in tabs2" :key="tab.id" class="ltr:mr-2 rtl:ml-2">
                            <button @click="handleTabClick2(tab.id)" class="inline-block p-4" :class="{
                                'text-purple border-b-2 border-purple': activeTab2 === tab.id,
                                'text-muted dark:text-darkmuted dark:hover:text-purple border-b-2 border-transparent rounded-t-lg hover:text-purple hover:border-purple': activeTab2 !== tab.id
                            }">
                                {{ tab.label }}
                            </button>
                        </li>
                        <li>
                            <button class="inline-block p-4 rounded-t-lg cursor-not-allowed text-muted/50" disabled>Disabled</button>
                        </li>
                    </ul>
                    <div class="tab-content mt-3 text-[13px]">
                        <div v-for="tab in tabs2" :key="tab.id" v-show="activeTab2 === tab.id">
                            <p>{{ tab.content }}</p>
                        </div>
                    </div>
                </div>
                <!-- Tabs with Icons -->
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">
                        Tabs with Icons
                    </h2>
                    <ul class="flex flex-wrap -mb-px text-sm text-center border-b border-black/10 dark:border-darkborder">
                        <li v-for="tab in tabsWithIcons" :key="tab.id" class="ltr:mr-2 rtl:ml-2">
                            <Link to="#" @click="handleIconTabClick(tab.id)" class="inline-flex p-4" :class="{
                                'text-purple border-b-2 border-purple': activeTabWithIcon === tab.id,
                                'text-muted dark:text-darkmuted dark:hover:text-purple border-b-2 border-transparent rounded-t-lg hover:text-purple hover:border-purple': activeTabWithIcon !== tab.id
                            }">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 ltr:mr-2 rtl:ml-2">
                                <!-- Use tab.icon here as the path to the icon -->
                                <path :d="tab.icon" fill="currentColor"></path>
                            </svg>
                            {{ tab.label }}
                            </Link>
                        </li>
                        <li>
                            <button class=" inline-block p-4 rounded-t-lg cursor-not-allowed text-muted/50" disabled>Disabled</button>
                        </li>
                    </ul>
                    <div class="tab-content mt-3 text-[13px]">
                        <div v-for="tab in tabsWithIcons" :key="tab.id" v-show="activeTabWithIcon === tab.id">
                            <p>{{ tab.content }}</p>
                        </div>
                    </div>
                </div>
                <!-- Tabs with Icons -->
                <!-- Pills tabs -->
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">
                        Pills tabs
                    </h2>
                    <div>
                        <ul class="flex flex-wrap text-sm text-center">
                            <li v-for="tab in tabsWithIcons" :key="tab.id" class="ltr:mr-2 rtl:ml-2">
                                <button @click="handlePillsTabClick(tab.id)" class="inline-block px-4 py-3 rounded-lg" :class="{
                                    'text-white bg-purple': activePillsTabs === tab.id,
                                    'text-muted dark:text-darkmuted dark:hover:text-purple bg-transparent hover:text-purple': activePillsTabs !== tab.id
                                }">
                                    {{ tab.label }}
                                </button>
                            </li>
                            <li>
                                <button class="inline-block px-4 py-3 cursor-not-allowed text-muted/50" disabled>Tab 5</button>
                            </li>
                        </ul>
                        <div class="tab-content mt-3 text-[13px]">
                            <div v-for="tab in tabsWithIcons" :key="tab.id" v-show="activePillsTabs === tab.id">
                                <p>{{ tab.content }}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Bar with icons -->
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">
                        Bar with icons
                    </h2>
                    <div>
                        <ul class="w-full overflow-hidden text-sm text-center divide-x rounded-lg shadow dark:divide-darkborder dark:shadow-darkborder divide-black/10 sm:flex">
                            <li class="w-full" v-for="tab in tabsWithIcons" :key="tab.id">
                                <button @click="handleBarWithTabClick(tab.id)" class="inline-flex justify-center w-full p-4 ltr:sm:rounded-l-lg rtl:sm:rounded-r-lg" :class="{
                                    'text-white bg-purple': activeBarTabs === tab.id,
                                    'text-muted bg-transparent hover:text-white dark:text-darkmuted dark:hover:text-white hover:bg-purple': activeBarTabs !== tab.id
                                }">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-5 h-5 ltr:mr-2 rtl:ml-2">
                                        <path fill="currentColor" :d="tab.icon" />
                                    </svg>{{ tab.label }}
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content mt-3 text-[13px]">
                            <div v-for="tab in tabsWithIcons" :key="tab.id" v-show="activeBarTabs === tab.id">
                                <p>{{ tab.content }}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Bar without icons -->
                <div class="p-5 bg-white border rounded border-black/10 dark:bg-darklight dark:border-darkborder">
                    <h2 class="mb-4 text-base font-semibold text-black capitalize dark:text-white/80">
                        Bar without icons
                    </h2>
                    <div>
                        <ul class="w-full overflow-hidden text-sm text-center divide-x rounded-lg shadow dark:divide-darkborder dark:shadow-darkborder divide-black/10 sm:flex">
                            <li class="w-full" v-for="tabs in tabsWithoutIcons" :key="tabs.id">
                                <button @click="handleBarTabClickd(tabs.id)" class="inline-flex justify-center w-full p-4 ltr:sm:rounded-l-lg rtl:sm:rounded-r-lg" :class="{
                                    'text-white bg-purple': activeBarsTabs === tabs.id,
                                    'text-muted bg-transparent hover:text-white dark:text-darkmuted dark:hover:text-white hover:bg-purple':
                                        activeBarsTabs !== tabs.id
                                }">
                                    {{ tabs.label }}
                                </button>
                            </li>
                            <!-- Repeat for other tabs -->
                        </ul>
                        <div class="tab-content mt-3 text-[13px]">
                            <div v-for="tabs in tabsWithoutIcons" :key="tabs.id" v-show="activeBarsTabs === tabs.id">
                                {{ tabs.id }}

                                <p>{{ tabs.content }}</p>
                            </div>
                            <!-- Repeat for other tab content -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </Layout>
</template>
