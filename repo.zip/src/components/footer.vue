<script setup>
import { ref } from 'vue';
const currentYear = ref(new Date().getFullYear());
</script>

<template>
    <!-- FOOTER (inside the content) -->
    <footer class="py-2 text-center text-black dark:text-darkmuted ltr:md:text-left rtl:md:text-right">
        &copy;
        {{ currentYear }} Sliced
        <span class="hidden ltr:float-right rtl:float-left md:inline-block">Crafted with
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-4 h-4 inline-block relative -mt-[2px]">
                <path d="M12.001 4.52853C14.35 2.42 17.98 2.49 20.2426 4.75736C22.5053 7.02472 22.583 10.637 20.4786 12.993L11.9999 21.485L3.52138 12.993C1.41705 10.637 1.49571 7.01901 3.75736 4.75736C6.02157 2.49315 9.64519 2.41687 12.001 4.52853Z" class="fill-purple"></path>
            </svg>
            by SRBThemes</span>
    </footer>
    <!-- !FOOTER (inside the content) -->
</template>
