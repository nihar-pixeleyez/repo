<script setup>
import { ref } from 'vue';
const direction = ref('ltr');
const toggleDirection = () => {
    direction.value = direction.value === 'ltr' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('dir', direction.value)
};
</script>

<template>
    <button type="button" class="fixed z-50 px-4 text-white border-gray-200 shadow-lg h-11 ltr:right-0 rtl:left-0 bg-purple ltr:rounded-l-md rtl:rounded-r-md top-1/3" @click="toggleDirection"><span class="rtl:hidden">RTL</span> <span class="ltr:hidden">LTR</span></button>
</template>